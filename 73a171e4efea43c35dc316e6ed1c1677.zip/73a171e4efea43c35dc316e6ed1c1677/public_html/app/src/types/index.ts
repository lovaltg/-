export interface Category {
  id: string;
  name: string;
  slug: string;
  type: 'game' | 'app' | 'service';
  icon: string | null;
  image_url: string | null;
  order_num: number;
  is_active: boolean;
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  category_id: string;
  order_num: number;
  is_active: boolean;
}

export interface Profile {
  id: string;
  username: string;
  avatar_url: string | null;
  email: string;
  balance: number;
  created_at: string;
  last_online: string;
  nickname_changed_at: string | null;
  is_admin: boolean;
  status: 'online' | 'offline';
}

export interface Lot {
  id: string;
  seller_id: string;
  category_id: string;
  subcategory_id: string | null;
  title: string;
  description: string;
  price: number;
  old_price: number | null;
  quantity: number;
  status: 'active' | 'sold' | 'inactive' | 'pending';
  images: string[];
  views: number;
  created_at: string;
  updated_at: string;
  seller?: Profile;
  category?: Category;
  subcategory?: Subcategory;
  rating?: number;
  reviews_count?: number;
}

export interface Chat {
  id: string;
  lot_id: string;
  buyer_id: string;
  seller_id: string;
  created_at: string;
  updated_at: string;
  lot?: Lot;
  buyer?: Profile;
  seller?: Profile;
}

export interface Message {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: Profile;
}

export interface Order {
  id: string;
  lot_id: string;
  buyer_id: string;
  seller_id: string;
  amount: number;
  status: 'pending' | 'paid' | 'completed' | 'cancelled' | 'disputed';
  created_at: string;
  updated_at: string;
  buyer?: Profile;
  seller?: Profile;
  lot?: Lot;
}

export interface Review {
  id: string;
  seller_id: string;
  reviewer_id: string;
  lot_id: string | null;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: Profile;
  lot?: Lot;
}

export interface SiteSettings {
  id: string;
  site_name: string;
  site_logo: string | null;
  support_telegram: string | null;
  created_at: string;
  updated_at: string;
}
