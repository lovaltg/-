import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getCategories, getLots, getSiteSettings } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { CategoryCard } from '@/components/CategoryCard';
import { LotCard } from '@/components/LotCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Gamepad2, Smartphone, MessageCircle, ChevronRight, ExternalLink } from 'lucide-react';
import type { Category, Lot, SiteSettings } from '@/types';

export function Home() {
  const [games, setGames] = useState<Category[]>([]);
  const [apps, setApps] = useState<Category[]>([]);
  const [services, setServices] = useState<Category[]>([]);
  const [featuredLots, setFeaturedLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    loadData();
    loadSiteSettings();
  }, []);

  const loadData = async () => {
    try {
      const { data: categoriesData } = await getCategories();
      if (categoriesData) {
        setGames(categoriesData.filter((c: Category) => c.type === 'game'));
        setApps(categoriesData.filter((c: Category) => c.type === 'app'));
        setServices(categoriesData.filter((c: Category) => c.type === 'service'));
      }
      const { data: lotsData } = await getLots({ status: 'active' });
      if (lotsData) setFeaturedLots(lotsData.slice(0, 8) as Lot[]);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadSiteSettings = async () => {
    const { data } = await getSiteSettings();
    if (data) setSiteSettings(data);
  };
  
  const siteName = siteSettings?.site_name || 'GameMarket';
  const supportTelegram = siteSettings?.support_telegram || '@LovelyConfig';

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <section className="mb-12">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-background border p-8 md:p-12">
            <div className="relative z-10 max-w-2xl">
              <h1 className="text-3xl md:text-5xl font-bold mb-4">Маркетплейс игровых товаров</h1>
              <p className="text-lg text-muted-foreground mb-6">Покупайте и продавайте игровые товары, аккаунты, валюту и услуги безопасно</p>
              <div className="flex flex-wrap gap-3">
                <Button size="lg" asChild><Link to="/games">Начать покупки</Link></Button>
                <Button size="lg" variant="outline" asChild><Link to="/sell">Стать продавцом</Link></Button>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <a href={`https://t.me/${supportTelegram.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="block">
            <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white transition-transform hover:scale-[1.01]">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold mb-2">Нужна помощь?</h2>
                  <p className="text-white/80">Напишите нам в Telegram {supportTelegram}</p>
                </div>
                <ExternalLink className="h-8 w-8" />
              </div>
            </div>
          </a>
        </section>

        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Популярные игры</h2>
              <Badge variant="secondary">{games.length}</Badge>
            </div>
            <Button variant="ghost" asChild><Link to="/games" className="flex items-center gap-1">Все игры<ChevronRight className="h-4 w-4" /></Link></Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {games.slice(0, 8).map((game) => <CategoryCard key={game.id} category={game} />)}
            </div>
          )}
        </section>

        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <MessageCircle className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Приложения и услуги</h2>
              <Badge variant="secondary">{apps.length}</Badge>
            </div>
            <Button variant="ghost" asChild><Link to="/apps" className="flex items-center gap-1">Все приложения<ChevronRight className="h-4 w-4" /></Link></Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {apps.slice(0, 8).map((app) => <CategoryCard key={app.id} category={app} />)}
            </div>
          )}
        </section>

        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Smartphone className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Мобильные игры и услуги</h2>
              <Badge variant="secondary">{services.length}</Badge>
            </div>
            <Button variant="ghost" asChild><Link to="/mobile-games" className="flex items-center gap-1">Все услуги<ChevronRight className="h-4 w-4" /></Link></Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {services.slice(0, 8).map((service) => <CategoryCard key={service.id} category={service} />)}
            </div>
          )}
        </section>

        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Новые лоты</h2>
            <Button variant="ghost" asChild><Link to="/lots" className="flex items-center gap-1">Все лоты<ChevronRight className="h-4 w-4" /></Link></Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-64 rounded-xl" />)}
            </div>
          ) : featuredLots.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {featuredLots.map((lot) => <LotCard key={lot.id} lot={lot} />)}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-xl">
              <p className="text-muted-foreground mb-4">Пока нет лотов</p>
              <Button asChild><Link to="/sell">Создать первый лот</Link></Button>
            </div>
          )}
        </section>
      </main>

      <footer className="border-t bg-muted/50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{siteName.slice(0, 2).toUpperCase()}</span>
                </div>
                <span className="font-bold text-xl">{siteName}</span>
              </div>
              <p className="text-sm text-muted-foreground">Безопасный маркетплейс для покупки и продажи игровых товаров</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Покупателям</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/games" className="hover:text-primary">Каталог игр</Link></li>
                <li><Link to="/lots" className="hover:text-primary">Все лоты</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Продавцам</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/sell" className="hover:text-primary">Создать лот</Link></li>
                <li><Link to="/finances" className="hover:text-primary">Финансы</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Поддержка</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href={`https://t.me/${supportTelegram.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary">Telegram поддержка</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">© 2025 {siteName}. Все права защищены.</div>
        </div>
      </footer>
    </div>
  );
}
