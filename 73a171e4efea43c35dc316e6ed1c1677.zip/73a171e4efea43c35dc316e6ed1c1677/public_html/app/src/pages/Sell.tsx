import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, getCategories, getSubcategories, createLot } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, Package, X, Loader2, Upload } from 'lucide-react';
import { toast } from 'sonner';
import type { Category, Subcategory } from '@/types';

export function Sell() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [subcategoryId, setSubcategoryId] = useState('');
  const [price, setPrice] = useState('');
  const [oldPrice, setOldPrice] = useState('');
  const [quantity, setQuantity] = useState('1');

  useEffect(() => { if (!user) return; loadCategories(); }, [user]);
  useEffect(() => { if (categoryId) loadSubcategories(categoryId); else { setSubcategories([]); setSubcategoryId(''); } }, [categoryId]);

  const loadCategories = async () => { const { data } = await getCategories(); if (data) setCategories(data as Category[]); setLoading(false); };
  const loadSubcategories = async (catId: string) => { const { data } = await getSubcategories(catId); if (data) setSubcategories(data as Subcategory[]); };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !user) return;
    setUploading(true);
    for (const file of Array.from(files)) {
      if (file.size > 5 * 1024 * 1024) { toast.error(`Файл слишком большой`); continue; }
      const fileName = `${user.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${file.name.split('.').pop()}`;
      const { error } = await supabase.storage.from('lot-images').upload(fileName, file);
      if (error) toast.error(`Ошибка загрузки`);
      else { const { data: { publicUrl } } = supabase.storage.from('lot-images').getPublicUrl(fileName); setImages(prev => [...prev, publicUrl].slice(0, 5)); }
    }
    setUploading(false);
  };

  const removeImage = (index: number) => setImages(prev => prev.filter((_, i) => i !== index));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { toast.error('Войдите в аккаунт'); navigate('/auth'); return; }
    if (!title || !description || !categoryId || !price) { toast.error('Заполните все обязательные поля'); return; }
    setSubmitting(true);
    const { data, error } = await createLot({ seller_id: user.id, category_id: categoryId, subcategory_id: subcategoryId || null, title, description, price: parseFloat(price), old_price: oldPrice ? parseFloat(oldPrice) : null, quantity: parseInt(quantity), images, status: 'active' });
    if (error) toast.error('Ошибка создания лота');
    else { toast.success('Лот успешно создан!'); navigate(`/lot/${data.id}`); }
    setSubmitting(false);
  };

  if (!user) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><Package className="h-16 w-16 mx-auto mb-4 text-muted-foreground" /><h1 className="text-2xl font-bold mb-4">Вход required</h1><Button asChild><Link to="/auth">Войти</Link></Button></main></div>;
  if (loading) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/" className="flex items-center gap-1"><ChevronLeft className="h-4 w-4" />На главную</Link></Button>
        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Создать лот</h1>
          <Card>
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2"><Label htmlFor="title">Название лота *</Label><Input id="title" placeholder="Например: 1000 серебряных осколков Rust" value={title} onChange={(e) => setTitle(e.target.value)} required /></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2"><Label htmlFor="category">Категория *</Label><Select value={categoryId} onValueChange={setCategoryId} required><SelectTrigger><SelectValue placeholder="Выберите категорию" /></SelectTrigger><SelectContent>{categories.map((cat) => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}</SelectContent></Select></div>
                  <div className="space-y-2"><Label htmlFor="subcategory">Подкатегория</Label><Select value={subcategoryId} onValueChange={setSubcategoryId} disabled={!categoryId || subcategories.length === 0}><SelectTrigger><SelectValue placeholder={subcategories.length === 0 ? "Нет подкатегорий" : "Выберите подкатегорию"} /></SelectTrigger><SelectContent>{subcategories.map((sub) => <SelectItem key={sub.id} value={sub.id}>{sub.name}</SelectItem>)}</SelectContent></Select></div>
                </div>
                <div className="space-y-2"><Label htmlFor="description">Описание *</Label><Textarea id="description" placeholder="Опишите товар..." value={description} onChange={(e) => setDescription(e.target.value)} required rows={4} className="resize-none" /></div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2"><Label htmlFor="price">Цена (₽) *</Label><Input id="price" type="number" placeholder="500" value={price} onChange={(e) => setPrice(e.target.value)} required min="1" /></div>
                  <div className="space-y-2"><Label htmlFor="oldPrice">Старая цена</Label><Input id="oldPrice" type="number" placeholder="650" value={oldPrice} onChange={(e) => setOldPrice(e.target.value)} min="1" /></div>
                  <div className="space-y-2"><Label htmlFor="quantity">Количество *</Label><Input id="quantity" type="number" placeholder="100" value={quantity} onChange={(e) => setQuantity(e.target.value)} required min="1" /></div>
                </div>
                <div className="space-y-2">
                  <Label>Изображения (до 5, макс. 5 МБ каждое)</Label>
                  <div className="flex flex-wrap gap-3">
                    {images.map((img, index) => <div key={index} className="relative h-20 w-20 rounded-lg overflow-hidden border"><img src={img} alt="" className="h-full w-full object-cover" /><button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 h-5 w-5 bg-red-500 text-white rounded-full flex items-center justify-center"><X className="h-3 w-3" /></button></div>)}
                    {images.length < 5 && <label className="h-20 w-20 rounded-lg border-2 border-dashed border-muted-foreground/25 flex flex-col items-center justify-center cursor-pointer hover:border-muted-foreground/50 transition-colors">{uploading ? <Loader2 className="h-6 w-6 text-muted-foreground animate-spin" /> : <><Upload className="h-6 w-6 text-muted-foreground" /><span className="text-xs text-muted-foreground mt-1">Добавить</span></>}<input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} disabled={uploading} /></label>}
                  </div>
                </div>
                <div className="flex gap-3 pt-2">
                  <Button type="submit" className="flex-1" disabled={submitting}>{submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{submitting ? 'Создание...' : 'Создать лот'}</Button>
                  <Button type="button" variant="outline" onClick={() => navigate('/')}>Отмена</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
