import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, getCategories, createCategory, updateCategory, deleteCategory, createSubcategory, deleteSubcategory, getSiteSettings, updateSiteSettings } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChevronLeft, Plus, Edit2, Trash2, ChevronDown, ChevronRight, Shield, LogOut, Gamepad2, Smartphone, AppWindow, Settings, Globe } from 'lucide-react';
import { toast } from 'sonner';
import type { Category, Subcategory } from '@/types';

export function Admin() {
  const { profile, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [categoryDialog, setCategoryDialog] = useState(false);
  const [subcategoryDialog, setSubcategoryDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [categoryName, setCategoryName] = useState('');
  const [categorySlug, setCategorySlug] = useState('');
  const [categoryType, setCategoryType] = useState<'game' | 'app' | 'service'>('game');
  const [subcategoryName, setSubcategoryName] = useState('');
  
  // Site settings state
  const [siteName, setSiteName] = useState('GameMarket');
  const [siteLogo, setSiteLogo] = useState('');
  const [supportTelegram, setSupportTelegram] = useState('@LovelyConfig');
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    if (!loading && !isAdmin) { navigate('/'); return; }
    loadCategories();
    loadSiteSettings();
  }, [isAdmin, loading]);
  
  const loadSiteSettings = async () => {
    const { data } = await getSiteSettings();
    if (data) {
      setSiteName(data.site_name || 'GameMarket');
      setSiteLogo(data.site_logo || '');
      setSupportTelegram(data.support_telegram || '@LovelyConfig');
    }
  };
  
  const handleSaveSiteSettings = async () => {
    setSavingSettings(true);
    const { error } = await updateSiteSettings({
      site_name: siteName,
      site_logo: siteLogo,
      support_telegram: supportTelegram
    });
    if (error) toast.error('Ошибка сохранения настроек');
    else toast.success('Настройки сохранены');
    setSavingSettings(false);
  };

  const loadCategories = async () => {
    const { data } = await getCategories();
    if (data) {
      const catsWithSubs = await Promise.all(data.map(async (cat: Category) => {
        const { data: subs } = await supabase.from('subcategories').select('*').eq('category_id', cat.id).eq('is_active', true);
        return { ...cat, subcategories: subs || [] };
      }));
      setCategories(catsWithSubs);
    }
    setLoading(false);
  };

  const handleSaveCategory = async () => {
    if (!categoryName || !categorySlug) { toast.error('Заполните все поля'); return; }
    if (editingCategory) {
      const { error } = await updateCategory(editingCategory.id, { name: categoryName, slug: categorySlug, type: categoryType });
      if (error) toast.error('Ошибка обновления'); else toast.success('Категория обновлена');
    } else {
      const { error } = await createCategory({ name: categoryName, slug: categorySlug, type: categoryType, order_num: categories.length + 1 });
      if (error) toast.error('Ошибка создания'); else toast.success('Категория создана');
    }
    setCategoryDialog(false);
    resetCategoryForm();
    loadCategories();
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Вы уверены?')) return;
    const { error } = await deleteCategory(id);
    if (error) toast.error('Ошибка удаления'); else { toast.success('Категория удалена'); loadCategories(); }
  };

  const handleAddSubcategory = async () => {
    if (!subcategoryName || !selectedCategoryId) { toast.error('Заполните название'); return; }
    const slug = subcategoryName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const { error } = await createSubcategory({ category_id: selectedCategoryId, name: subcategoryName, slug });
    if (error) toast.error('Ошибка создания'); else { toast.success('Подкатегория создана'); setSubcategoryDialog(false); setSubcategoryName(''); loadCategories(); }
  };

  const handleDeleteSubcategory = async (id: string) => {
    if (!confirm('Вы уверены?')) return;
    const { error } = await deleteSubcategory(id);
    if (error) toast.error('Ошибка удаления'); else { toast.success('Подкатегория удалена'); loadCategories(); }
  };

  const resetCategoryForm = () => { setCategoryName(''); setCategorySlug(''); setCategoryType('game'); setEditingCategory(null); };
  const openEditCategory = (cat: Category) => { setEditingCategory(cat); setCategoryName(cat.name); setCategorySlug(cat.slug); setCategoryType(cat.type); setCategoryDialog(true); };
  const openAddSubcategory = (categoryId: string) => { setSelectedCategoryId(categoryId); setSubcategoryDialog(true); };
  const getTypeIcon = (type: string) => { switch (type) { case 'game': return <Gamepad2 className="h-4 w-4" />; case 'app': return <AppWindow className="h-4 w-4" />; case 'service': return <Smartphone className="h-4 w-4" />; default: return null; } };

  if (loading) return <div className="min-h-screen bg-background"><Header /><div className="flex items-center justify-center h-[calc(100vh-64px)]"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div></div>;
  if (!isAdmin) return <div className="min-h-screen bg-background"><Header /><div className="flex items-center justify-center h-[calc(100vh-64px)] text-center"><Shield className="h-16 w-16 mx-auto mb-4 text-muted-foreground" /><h1 className="text-2xl font-bold mb-2">Доступ запрещен</h1><Button asChild><Link to="/">На главную</Link></Button></div></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild><Link to="/"><ChevronLeft className="h-5 w-5" /></Link></Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2"><Shield className="h-6 w-6 text-primary" />Админ-панель</h1>
              <p className="text-sm text-muted-foreground">{profile?.username}</p>
            </div>
          </div>
          <Button variant="outline" onClick={signOut}><LogOut className="h-4 w-4 mr-2" />Выйти</Button>
        </div>
        
        <Tabs defaultValue="categories" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="categories"><Gamepad2 className="h-4 w-4 mr-2" />Категории</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="h-4 w-4 mr-2" />Настройки сайта</TabsTrigger>
          </TabsList>
          
          <TabsContent value="categories">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Категории</CardTitle>
                <Button onClick={() => setCategoryDialog(true)}><Plus className="h-4 w-4 mr-2" />Добавить</Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.id} className="border rounded-lg">
                      <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/50" onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}>
                        <div className="flex items-center gap-3">
                          <button className="p-1">{expandedCategory === category.id ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}</button>
                          {getTypeIcon(category.type)}
                          <span className="font-medium">{category.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); openAddSubcategory(category.id); }}><Plus className="h-4 w-4 mr-1" />Подкатегория</Button>
                          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); openEditCategory(category); }}><Edit2 className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="text-red-500" onClick={(e) => { e.stopPropagation(); handleDeleteCategory(category.id); }}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </div>
                      {expandedCategory === category.id && (category as any).subcategories && (
                        <div className="border-t bg-muted/30">
                          {(category as any).subcategories.length > 0 ? <div className="divide-y">{(category as any).subcategories.map((sub: Subcategory) => <div key={sub.id} className="flex items-center justify-between px-12 py-2"><span className="text-sm">{sub.name}</span><Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => handleDeleteSubcategory(sub.id)}><Trash2 className="h-4 w-4" /></Button></div>)}</div> : <p className="px-12 py-4 text-sm text-muted-foreground">Нет подкатегорий</p>}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Globe className="h-5 w-5" />Настройки сайта</CardTitle>
                <CardDescription>Измените название сайта, логотип и другие параметры</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Название сайта</Label>
                  <Input 
                    id="siteName" 
                    value={siteName} 
                    onChange={(e) => setSiteName(e.target.value)} 
                    placeholder="GameMarket"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="siteLogo">URL логотипа (опционально)</Label>
                  <Input 
                    id="siteLogo" 
                    value={siteLogo} 
                    onChange={(e) => setSiteLogo(e.target.value)} 
                    placeholder="https://example.com/logo.png"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supportTelegram">Telegram поддержки</Label>
                  <Input 
                    id="supportTelegram" 
                    value={supportTelegram} 
                    onChange={(e) => setSupportTelegram(e.target.value)} 
                    placeholder="@username"
                  />
                </div>
                <Button 
                  onClick={handleSaveSiteSettings} 
                  disabled={savingSettings}
                  className="w-full sm:w-auto"
                >
                  {savingSettings ? 'Сохранение...' : 'Сохранить настройки'}
                </Button>
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Данные для входа в админ-панель</CardTitle>
                <CardDescription>Используйте эти данные для доступа к админ-панели</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm"><strong>Логин:</strong> ваш email при регистрации</p>
                  <p className="text-sm mt-2"><strong>Пароль:</strong> ваш пароль при регистрации</p>
                  <p className="text-sm mt-2 text-muted-foreground">
                    Для получения прав администратора нужно установить флаг is_admin = true в таблице profiles через Supabase Dashboard
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <Dialog open={categoryDialog} onOpenChange={setCategoryDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingCategory ? 'Редактировать категорию' : 'Новая категория'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-4">
            <div><Label>Название</Label><Input value={categoryName} onChange={(e) => { setCategoryName(e.target.value); if (!editingCategory) setCategorySlug(e.target.value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')); }} placeholder="Например: Rust" /></div>
            <div><Label>URL (slug)</Label><Input value={categorySlug} onChange={(e) => setCategorySlug(e.target.value)} placeholder="rust" /></div>
            <div><Label>Тип</Label><div className="flex gap-2 mt-2">{(['game', 'app', 'service'] as const).map((type) => <Button key={type} variant={categoryType === type ? 'default' : 'outline'} onClick={() => setCategoryType(type)} className="flex-1">{type === 'game' ? 'Игра' : type === 'app' ? 'Приложение' : 'Услуга'}</Button>)}</div></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setCategoryDialog(false); resetCategoryForm(); }}>Отмена</Button>
            <Button onClick={handleSaveCategory}>{editingCategory ? 'Сохранить' : 'Создать'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={subcategoryDialog} onOpenChange={setSubcategoryDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Новая подкатегория</DialogTitle></DialogHeader>
          <div className="py-4"><Label>Название</Label><Input value={subcategoryName} onChange={(e) => setSubcategoryName(e.target.value)} placeholder="Например: Аккаунты" /></div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setSubcategoryDialog(false); setSubcategoryName(''); }}>Отмена</Button>
            <Button onClick={handleAddSubcategory}>Создать</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
