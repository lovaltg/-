import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getLots, deleteLot, updateLot } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronLeft, Package, Plus, Edit, Trash2, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import type { Lot } from '@/types';

export function MyLots() {
  const { user } = useAuth();
  const [lots, setLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { if (user) loadLots(); }, [user]);

  const loadLots = async () => {
    setLoading(true);
    const { data } = await getLots({ seller_id: user?.id });
    if (data) setLots(data as Lot[]);
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот лот?')) return;
    const { error } = await deleteLot(id);
    if (error) toast.error('Ошибка удаления');
    else { toast.success('Лот удален'); loadLots(); }
  };

  const handleToggleStatus = async (lot: Lot) => {
    const newStatus = lot.status === 'active' ? 'inactive' : 'active';
    const { error } = await updateLot(lot.id, { status: newStatus });
    if (error) toast.error('Ошибка обновления');
    else { toast.success(newStatus === 'active' ? 'Лот активирован' : 'Лот деактивирован'); loadLots(); }
  };

  if (!user) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><Package className="h-16 w-16 mx-auto mb-4 text-muted-foreground" /><h1 className="text-2xl font-bold mb-4">Вход required</h1><Button asChild><Link to="/auth">Войти</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/" className="flex items-center gap-1"><ChevronLeft className="h-4 w-4" />На главную</Link></Button>
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Мои лоты</h1>
          <Button asChild><Link to="/sell"><Plus className="h-4 w-4 mr-2" />Создать лот</Link></Button>
        </div>
        {loading ? <div className="space-y-4">{[1,2,3].map((i) => <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />)}</div> : lots.length > 0 ? <div className="space-y-4">{lots.map((lot) => <Card key={lot.id}><CardContent className="p-4"><div className="flex flex-col sm:flex-row gap-4"><div className="h-20 w-full sm:h-24 sm:w-24 rounded-lg overflow-hidden bg-muted shrink-0">{lot.images && lot.images.length > 0 ? <img src={lot.images[0]} alt={lot.title} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5"><span className="text-xl font-bold text-primary/30">{lot.title.charAt(0)}</span></div>}</div><div className="flex-1 min-w-0"><div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2"><div><Link to={`/lot/${lot.id}`} className="font-semibold hover:text-primary line-clamp-2">{lot.title}</Link><div className="flex items-center gap-2 mt-1"><Badge variant="secondary">{lot.category?.name}</Badge><Badge variant={lot.status === 'active' ? 'default' : 'secondary'} className={lot.status === 'active' ? 'bg-green-600' : ''}>{lot.status === 'active' ? 'Активен' : 'Неактивен'}</Badge></div></div><div className="text-left sm:text-right shrink-0"><div className="text-xl font-bold text-green-600 dark:text-green-400">{lot.price.toLocaleString('ru-RU')} ₽</div><div className="text-sm text-muted-foreground">В наличии: {lot.quantity}</div></div></div><div className="flex flex-wrap gap-2 mt-4"><Button variant="outline" size="sm" onClick={() => handleToggleStatus(lot)}>{lot.status === 'active' ? <><EyeOff className="h-4 w-4 mr-1.5" />Скрыть</> : <><Eye className="h-4 w-4 mr-1.5" />Показать</>}</Button><Button variant="outline" size="sm"><Edit className="h-4 w-4 mr-1.5" />Редактировать</Button><Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => handleDelete(lot.id)}><Trash2 className="h-4 w-4 mr-1.5" />Удалить</Button></div></div></div></CardContent></Card>)}</div> : <div className="text-center py-20"><Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" /><p className="text-muted-foreground mb-4">У вас пока нет лотов</p><Button asChild><Link to="/sell">Создать первый лот</Link></Button></div>}
      </main>
    </div>
  );
}
