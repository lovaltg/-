import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, getChats, subscribeToChats } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, MessageSquare, ShoppingBag } from 'lucide-react';
import type { Chat } from '@/types';

export function Chats() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/auth'); return; }
    loadChats();
    const subscription = subscribeToChats(user.id, () => loadChats());
    return () => { subscription.unsubscribe(); };
  }, [user]);

  const loadChats = async () => {
    if (!user) return;
    const { data } = await getChats(user.id);
    if (data) {
      const chatsWithUnread = await Promise.all(data.map(async (chat: Chat) => {
        const { count } = await supabase.from('messages').select('*', { count: 'exact' }).eq('chat_id', chat.id).eq('is_read', false).neq('sender_id', user.id);
        return { ...chat, unread_count: count || 0 };
      }));
      setChats(chatsWithUnread);
    }
    setLoading(false);
  };

  const getOtherUser = (chat: Chat) => chat.buyer_id === user?.id ? chat.seller : chat.buyer;

  if (!user) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><MessageSquare className="h-16 w-16 mx-auto mb-4 text-muted-foreground" /><h1 className="text-2xl font-bold mb-4">Вход required</h1><Button asChild><Link to="/auth">Войти</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" asChild><Link to="/"><ChevronLeft className="h-5 w-5" /></Link></Button>
          <h1 className="text-2xl font-bold">Мои чаты</h1>
        </div>
        {loading ? <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />)}</div> : chats.length > 0 ? (
          <div className="space-y-2">
            {chats.map((chat) => {
              const otherUser = getOtherUser(chat);
              // Реальная проверка онлайна - был ли пользователь активен в последние 5 минут
              const isOnline = otherUser?.last_online 
                ? (new Date().getTime() - new Date(otherUser.last_online).getTime()) < 5 * 60 * 1000 
                : false;
              return (
                <Link key={chat.id} to={`/chat/${chat.id}`} className="flex items-center gap-4 p-4 bg-card rounded-lg border hover:border-primary transition-colors">
                  <div className="relative">
                    <Avatar className="h-12 w-12"><AvatarImage src={otherUser?.avatar_url || ''} /><AvatarFallback>{otherUser?.username?.[0]}</AvatarFallback></Avatar>
                    {isOnline && <span className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-card" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">{otherUser?.username}</p>
                      <span className="text-xs text-muted-foreground">{new Date(chat.updated_at).toLocaleDateString('ru-RU')}</span>
                    </div>
                    {chat.lot && <div className="flex items-center gap-2 mt-1"><ShoppingBag className="h-3 w-3 text-muted-foreground" /><p className="text-sm text-muted-foreground truncate">{chat.lot.title}</p></div>}
                  </div>
                  {(chat as any).unread_count > 0 && <Badge className="bg-primary text-primary-foreground">{(chat as any).unread_count}</Badge>}
                </Link>
              );
            })}
          </div>
        ) : <div className="text-center py-20"><MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" /><p className="text-muted-foreground mb-4">У вас пока нет чатов</p><Button asChild><Link to="/games">Найти продавцов</Link></Button></div>}
      </main>
    </div>
  );
}
