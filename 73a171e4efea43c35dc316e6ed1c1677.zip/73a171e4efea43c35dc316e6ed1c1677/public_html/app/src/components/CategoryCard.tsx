import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Gamepad2, AppWindow, Smartphone } from 'lucide-react';
import type { Category } from '@/types';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  const getTypeIcon = () => {
    switch (category.type) {
      case 'game': return <Gamepad2 className="h-4 w-4" />;
      case 'app': return <AppWindow className="h-4 w-4" />;
      case 'service': return <Smartphone className="h-4 w-4" />;
      default: return null;
    }
  };

  const getTypeLabel = () => {
    switch (category.type) {
      case 'game': return 'Игра';
      case 'app': return 'Приложение';
      case 'service': return 'Услуга';
      default: return '';
    }
  };

  return (
    <Link to={`/category/${category.slug}`} className="group relative overflow-hidden rounded-xl border bg-card p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
      <div className="flex items-center gap-4">
        <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
          {category.image_url ? (
            <img src={category.image_url} alt={category.name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110" />
          ) : (
            <span className="text-xl font-bold text-primary">{category.name.charAt(0)}</span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-lg truncate">{category.name}</h3>
          <Badge variant="secondary" className="text-xs flex items-center gap-1 w-fit mt-1">
            {getTypeIcon()}
            {getTypeLabel()}
          </Badge>
        </div>
      </div>
    </Link>
  );
}
