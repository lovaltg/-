import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MessageSquare, Star } from 'lucide-react';
import { createChat } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Lot } from '@/types';

interface LotCardProps {
  lot: Lot;
}

export function LotCard({ lot }: LotCardProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const discount = lot.old_price ? Math.round(((lot.old_price - lot.price) / lot.old_price) * 100) : null;
  const isOwnLot = lot.seller_id === user?.id;
  const isOnline = lot.seller?.status === 'online';

  const handleChatClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) { toast.error('Войдите в аккаунт'); navigate('/auth'); return; }
    if (isOwnLot) { toast.error('Вы не можете написать самому себе'); return; }
    
    const { data: chat, error } = await createChat(lot.id, user.id, lot.seller_id);
    if (error) toast.error('Ошибка создания чата');
    else if (chat) navigate(`/chat/${chat.id}`);
  };

  return (
    <div className="group relative overflow-hidden rounded-xl border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
      <Link to={`/lot/${lot.id}`} className="block">
        <div className="relative aspect-video overflow-hidden">
          {lot.images && lot.images.length > 0 ? (
            <img src={lot.images[0]} alt={lot.title} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
              <span className="text-4xl font-bold text-primary/30">{lot.title.charAt(0)}</span>
            </div>
          )}
          {discount && discount > 0 && <Badge className="absolute top-2 right-2 bg-red-500 text-white">-{discount}%</Badge>}
        </div>
      </Link>

      <div className="p-4">
        <Link to={`/lot/${lot.id}`}>
          <h3 className="font-semibold text-base line-clamp-2 min-h-[48px] hover:text-primary transition-colors">{lot.title}</h3>
        </Link>

        <div className="mt-3 flex items-center gap-2">
          <Link to={`/profile/${lot.seller_id}`} className="flex items-center gap-2 flex-1 min-w-0">
            {lot.seller?.avatar_url ? (
              <img src={lot.seller.avatar_url} alt={lot.seller.username} className="h-6 w-6 rounded-full object-cover" />
            ) : (
              <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-xs font-medium text-primary">{lot.seller?.username?.charAt(0) || '?'}</span>
              </div>
            )}
            <span className="text-sm text-muted-foreground truncate">{lot.seller?.username || 'Продавец'}</span>
            {isOnline && <span className="h-2 w-2 bg-green-500 rounded-full shrink-0" />}
          </Link>
          {lot.rating && <div className="flex items-center gap-1"><Star className="h-3 w-3 fill-yellow-400 text-yellow-400" /><span className="text-xs">{lot.rating.toFixed(1)}</span></div>}
        </div>

        <div className="mt-3 flex items-end justify-between">
          <div>
            <div className="text-xl font-bold text-green-600 dark:text-green-400">{lot.price.toLocaleString('ru-RU')} ₽</div>
            {lot.old_price && <div className="text-sm text-muted-foreground line-through">{lot.old_price.toLocaleString('ru-RU')} ₽</div>}
          </div>
          {lot.reviews_count !== undefined && lot.reviews_count > 0 && <span className="text-xs text-muted-foreground">{lot.reviews_count} отзывов</span>}
        </div>

        <div className="mt-4 flex gap-2">
          <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white" size="sm" asChild>
            <Link to={`/lot/${lot.id}`}>Купить</Link>
          </Button>
          {!isOwnLot && (
            <Button variant="outline" size="sm" onClick={handleChatClick} className="px-3">
              <MessageSquare className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
