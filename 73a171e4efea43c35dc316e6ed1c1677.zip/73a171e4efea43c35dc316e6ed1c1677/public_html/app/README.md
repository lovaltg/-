# GameMarket - Маркетплейс игровых товаров

## Описание

GameMarket - это безопасный маркетплейс для покупки и продажи игровых товаров, аккаунтов, валюты и услуг.

## Функции

- 🔐 Авторизация через Google и Email
- 🎮 Каталог игр, приложений и услуг
- 📦 Создание и управление лотами
- 💬 Чат между покупателями и продавцами
- ⭐ Система отзывов и рейтингов
- 👤 Профили пользователей с аватарками
- 💰 Баланс и финансы
- 🔧 Админ-панель для управления сайтом

## Технологии

- React + TypeScript + Vite
- Tailwind CSS + shadcn/ui
- Supabase (База данных + Auth + Storage)

## Установка и запуск

### 1. Клонирование репозитория

```bash
git clone https://github.com/lovaltg/32432234.git
 cd 32432234/app
```

### 2. Установка зависимостей

```bash
npm install
```

### 3. Настройка переменных окружения

Создайте файл `.env` в корне проекта (уже создан):

```env
VITE_SUPABASE_URL=https://dgulvuqokunvuvfwanls.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRndWx2dXFva3VudnV2ZndhbmxzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE0OTcyMTQsImV4cCI6MjA4NzA3MzIxNH0.-ZTm58m_wSAGcm28iEcH0NERorTfcoK-afBlWC6PMCQ
```

### 4. Настройка базы данных Supabase

1. Зайдите в [Supabase Dashboard](https://app.supabase.com)
2. Создайте новый проект или используйте существующий
3. Перейдите в SQL Editor
4. Выполните скрипт из файла `supabase_schema.sql` (находится в корне проекта)

### 5. Настройка Storage Buckets

В Supabase Dashboard перейдите в Storage и создайте два bucket:
- `avatars` - для аватарок пользователей (public)
- `lot-images` - для изображений лотов (public)

Для каждого bucket настройте политики:
- SELECT: разрешить всем
- INSERT: разрешить аутентифицированным пользователям

### 6. Запуск проекта

```bash
npm run dev
```

Проект будет доступен по адресу `http://localhost:5173`

### 7. Сборка для production

```bash
npm run build
```

Собранные файлы будут в папке `dist/`

---

## Админ-панель

### Как получить доступ к админ-панели

1. Зарегистрируйтесь на сайте через Google или Email
2. Зайдите в Supabase Dashboard → Table Editor → profiles
3. Найдите свой профиль и установите `is_admin = true`
4. Перезагрузите страницу сайта
5. В меню профиля появится пункт "Админ-панель"

### URL админ-панели

```
https://your-site.com/#/admin
```

### Функции админ-панели

- **Категории**: добавление, редактирование, удаление категорий и подкатегорий
- **Настройки сайта**: изменение названия сайта, логотипа, Telegram поддержки

### Данные для входа

- **Логин**: ваш email при регистрации
- **Пароль**: ваш пароль при регистрации
- **Права админа**: устанавливаются через Supabase Dashboard (поле `is_admin` в таблице `profiles`)

---

## Структура базы данных

### Таблицы

#### profiles
- `id` - UUID пользователя (primary key)
- `username` - никнейм
- `email` - email
- `avatar_url` - URL аватарки
- `balance` - баланс
- `created_at` - дата регистрации
- `last_online` - последняя активность
- `is_admin` - флаг администратора
- `status` - статус онлайн/офлайн

#### categories
- `id` - UUID категории
- `name` - название
- `slug` - URL-идентификатор
- `type` - тип (game/app/service)
- `order_num` - порядок сортировки
- `is_active` - активна ли категория

#### subcategories
- `id` - UUID подкатегории
- `category_id` - ID родительской категории
- `name` - название
- `slug` - URL-идентификатор

#### lots
- `id` - UUID лота
- `seller_id` - ID продавца
- `category_id` - ID категории
- `subcategory_id` - ID подкатегории
- `title` - название
- `description` - описание
- `price` - цена
- `old_price` - старая цена
- `quantity` - количество
- `status` - статус (active/sold/inactive/pending)
- `images` - массив URL изображений
- `views` - количество просмотров

#### chats
- `id` - UUID чата
- `lot_id` - ID лота (или 'direct' для прямых чатов)
- `buyer_id` - ID покупателя
- `seller_id` - ID продавца

#### messages
- `id` - UUID сообщения
- `chat_id` - ID чата
- `sender_id` - ID отправителя
- `content` - текст сообщения
- `is_read` - прочитано ли

#### orders
- `id` - UUID заказа
- `lot_id` - ID лота
- `buyer_id` - ID покупателя
- `seller_id` - ID продавца
- `amount` - сумма
- `status` - статус (pending/paid/completed/cancelled/disputed)

#### reviews
- `id` - UUID отзыва
- `seller_id` - ID продавца
- `reviewer_id` - ID автора отзыва
- `lot_id` - ID лота
- `rating` - оценка (1-5)
- `comment` - текст отзыва

#### site_settings
- `id` - ID настроек (всегда '1')
- `site_name` - название сайта
- `site_logo` - URL логотипа
- `support_telegram` - Telegram для поддержки

---

## Решение проблем

### Ошибка загрузки аватарки

1. Проверьте, что bucket `avatars` создан в Supabase Storage
2. Проверьте политики доступа к bucket
3. Убедитесь, что файл не превышает 10 МБ

### Чат не работает

1. Проверьте, что таблицы `chats` и `messages` созданы
2. Проверьте RLS политики для этих таблиц
3. Убедитесь, что Realtime включен в Supabase Dashboard

### Не отображаются категории

1. Выполните SQL скрипт для создания категорий
2. Проверьте, что категории имеют `is_active = true`

---

## Контакты

- Telegram поддержка: @LovelyConfig
- Разработчик: lovelygames2024@gmail.com

---

## Лицензия

© 2025 GameMarket. Все права защищены.
