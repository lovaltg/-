import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { Home } from '@/pages/Home';
import { Toaster } from '@/components/ui/sonner';

// Lazy load other pages
import { Category } from '@/pages/Category';
import { Lot } from '@/pages/Lot';
import { Profile } from '@/pages/Profile';
import { Chats } from '@/pages/Chats';
import { Chat } from '@/pages/Chat';
import { Finances } from '@/pages/Finances';
import { Auth } from '@/pages/Auth';
import { Sell } from '@/pages/Sell';
import { Games } from '@/pages/Games';
import { MyLots } from '@/pages/MyLots';
import { Settings } from '@/pages/Settings';
import { Admin } from '@/pages/Admin';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <HashRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/category/:slug" element={<Category />} />
            <Route path="/lot/:id" element={<Lot />} />
            <Route path="/profile/:id" element={<Profile />} />
            <Route path="/chats" element={<Chats />} />
            <Route path="/chat/:id" element={<Chat />} />
            <Route path="/finances" element={<Finances />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/auth/callback" element={<Navigate to="/" />} />
            <Route path="/sell" element={<Sell />} />
            <Route path="/games" element={<Games />} />
            <Route path="/apps" element={<Games />} />
            <Route path="/mobile-games" element={<Games />} />
            <Route path="/my-lots" element={<MyLots />} />
            <Route path="/lots" element={<Games />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </HashRouter>
        <Toaster />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
