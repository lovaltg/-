import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, getProfile, updateUserStatus, isAdmin as checkIsAdmin } from '@/lib/supabase';

interface Profile {
  id: string;
  username: string;
  avatar_url: string | null;
  email: string;
  balance: number;
  created_at: string;
  last_online: string;
  nickname_changed_at: string | null;
  is_admin: boolean;
  status: 'online' | 'offline';
}

interface AuthContextType {
  user: any;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<{ error: any }>;
  signUpWithEmail: (email: string, password: string, username: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ error: any }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }: any) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        updateUserStatus('online');
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event: any, session: any) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        updateUserStatus('online');
      } else {
        setProfile(null);
        setIsAdmin(false);
        setLoading(false);
      }
    });

    const handleVisibilityChange = () => {
      if (user) updateUserStatus(document.hidden ? 'offline' : 'online');
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const interval = setInterval(() => { if (user) updateUserStatus('online'); }, 60000);

    return () => {
      subscription.unsubscribe();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(interval);
    };
  }, [user?.id]);

  const loadProfile = async (userId: string) => {
    const { data } = await getProfile(userId);
    if (data) {
      setProfile(data as Profile);
      setIsAdmin(await checkIsAdmin(userId));
    }
    setLoading(false);
  };

  const refreshProfile = async () => { if (user) await loadProfile(user.id); };

  const handleSignOut = async () => {
    await updateUserStatus('offline');
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setIsAdmin(false);
  };

  const updateProfileFn = async (updates: Partial<Profile>) => {
    if (!user) return { error: new Error('Not authenticated') };
    const { error } = await supabase.from('profiles').update(updates).eq('id', user.id);
    if (!error) await refreshProfile();
    return { error };
  };

  return (
    <AuthContext.Provider value={{
      user, profile, loading, isAdmin,
      signInWithGoogle: async () => { await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${window.location.origin}/#/auth/callback` } }); },
      signInWithEmail: async (email, password) => await supabase.auth.signInWithPassword({ email, password }),
      signUpWithEmail: async (email, password, username) => await supabase.auth.signUp({ email, password, options: { data: { username }, emailRedirectTo: `${window.location.origin}/#/auth/callback` } }),
      signOut: handleSignOut,
      updateProfile: updateProfileFn,
      refreshProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}
