import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, uploadAvatar } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ChevronLeft, Camera, Mail, Calendar, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const AVATAR_PRESETS = [
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Zack',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Bella',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Leo',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Molly',
];

export function Settings() {
  const { user, profile, updateProfile, refreshProfile } = useAuth();
  const [username, setUsername] = useState(profile?.username || '');
  const [selectedAvatar, setSelectedAvatar] = useState(profile?.avatar_url || '');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [canChangeNickname, setCanChangeNickname] = useState(true);
  const [daysUntilChange, setDaysUntilChange] = useState(0);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    checkNicknameChange();
  }, [user]);

  useEffect(() => {
    const checkUsername = async () => {
      if (username.length < 3 || username === profile?.username) { setUsernameAvailable(null); return; }
      const { data } = await supabase.from('profiles').select('id').eq('username', username).neq('id', user?.id).maybeSingle();
      setUsernameAvailable(!data);
    };
    const timeout = setTimeout(checkUsername, 500);
    return () => clearTimeout(timeout);
  }, [username]);

  const checkNicknameChange = async () => {
    if (!user) return;
    const { data } = await supabase.from('profiles').select('nickname_changed_at').eq('id', user.id).single();
    if (data?.nickname_changed_at) {
      const lastChange = new Date(data.nickname_changed_at);
      const daysPassed = (new Date().getTime() - lastChange.getTime()) / (1000 * 60 * 60 * 24);
      if (daysPassed < 14) { setCanChangeNickname(false); setDaysUntilChange(Math.ceil(14 - daysPassed)); }
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 10 * 1024 * 1024) { toast.error('Файл слишком большой (макс. 10 МБ)'); return; }
    setUploading(true);
    const { data, error } = await uploadAvatar(user.id, file);
    if (error) toast.error('Ошибка загрузки аватарки');
    else { setSelectedAvatar(data || ''); toast.success('Аватарка загружена'); refreshProfile(); }
    setUploading(false);
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const updates: any = { avatar_url: selectedAvatar };
    if (username !== profile?.username) {
      if (!canChangeNickname) { toast.error(`Никнейм можно менять раз в 14 дней. Осталось ${daysUntilChange} дней`); setSaving(false); return; }
      const { data: existing } = await supabase.from('profiles').select('id').eq('username', username).neq('id', user.id).maybeSingle();
      if (existing) { toast.error('Этот никнейм уже занят'); setSaving(false); return; }
      updates.username = username;
      updates.nickname_changed_at = new Date().toISOString();
    }
    const { error } = await updateProfile(updates);
    if (error) toast.error('Ошибка сохранения');
    else { toast.success('Профиль обновлен'); refreshProfile(); checkNicknameChange(); }
    setSaving(false);
  };

  if (!user || !profile) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><p className="text-muted-foreground">Войдите в аккаунт</p><Button asChild className="mt-4"><Link to="/auth">Войти</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" asChild><Link to="/"><ChevronLeft className="h-5 w-5" /></Link></Button>
          <h1 className="text-2xl font-bold">Настройки профиля</h1>
        </div>
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20"><AvatarImage src={profile.avatar_url || ''} /><AvatarFallback className="text-2xl">{profile.username?.[0]}</AvatarFallback></Avatar>
              <div>
                <h2 className="text-xl font-semibold">{profile.username}</h2>
                <p className="text-muted-foreground flex items-center gap-2"><Mail className="h-4 w-4" />{profile.email}</p>
                <p className="text-sm text-muted-foreground mt-1 flex items-center gap-2"><Calendar className="h-4 w-4" />На сайте с {new Date(profile.created_at).toLocaleDateString('ru-RU')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Аватарка</CardTitle>
            <CardDescription>Выберите аватарку или загрузите свою (до 10 МБ)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-6 gap-3">
              {AVATAR_PRESETS.map((avatar, idx) => (
                <button key={idx} onClick={() => setSelectedAvatar(avatar)} className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${selectedAvatar === avatar ? 'border-primary ring-2 ring-primary' : 'border-muted hover:border-primary/50'}`}>
                  <img src={avatar} alt="" className="h-full w-full object-cover" />
                  {selectedAvatar === avatar && <div className="absolute inset-0 bg-primary/20 flex items-center justify-center"><CheckCircle className="h-6 w-6 text-primary" /></div>}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileUpload} />
              <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Camera className="h-4 w-4 mr-2" />}
                Загрузить свою
              </Button>
              {selectedAvatar && !AVATAR_PRESETS.includes(selectedAvatar) && <div className="h-12 w-12 rounded-lg overflow-hidden border"><img src={selectedAvatar} alt="" className="h-full w-full object-cover" /></div>}
            </div>
          </CardContent>
        </Card>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Никнейм</CardTitle>
            <CardDescription className="flex items-center gap-2">
              {!canChangeNickname ? <><AlertCircle className="h-4 w-4 text-amber-500" />Можно менять раз в 14 дней. Осталось {daysUntilChange} дней</> : <><CheckCircle className="h-4 w-4 text-green-500" />Можно изменить</>}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Input value={username} onChange={(e) => setUsername(e.target.value)} disabled={!canChangeNickname} className="pr-10" />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {usernameAvailable === true && <CheckCircle className="h-5 w-5 text-green-500" />}
                {usernameAvailable === false && <span className="text-red-500 text-xs">×</span>}
              </div>
            </div>
            {usernameAvailable === false && <p className="text-sm text-red-500 mt-1">Этот никнейм уже занят</p>}
          </CardContent>
        </Card>
        <Card className="mb-6">
          <CardHeader><CardTitle>Баланс</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold">{profile.balance?.toLocaleString('ru-RU')} ₽</p>
                <p className="text-sm text-muted-foreground">Доступно для вывода</p>
              </div>
              <Button asChild><Link to="/finances">Пополнить</Link></Button>
            </div>
          </CardContent>
        </Card>
        <div className="flex gap-3">
          <Button className="flex-1" onClick={handleSave} disabled={saving || (username === profile.username && selectedAvatar === profile.avatar_url)}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Сохранить изменения
          </Button>
          <Button variant="outline" asChild><Link to={`/profile/${profile.id}`}>Просмотреть профиль</Link></Button>
        </div>
      </main>
    </div>
  );
}
