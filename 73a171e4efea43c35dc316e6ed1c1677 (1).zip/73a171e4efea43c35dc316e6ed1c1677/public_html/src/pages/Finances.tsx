import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, Wallet, ArrowDownLeft, ArrowUpRight, Plus, History } from 'lucide-react';

interface Transaction {
  id: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'payment' | 'refund';
  description: string;
  date: string;
}

const mockTransactions: Transaction[] = [
  { id: '1', amount: 5000, type: 'deposit', description: 'Пополнение через СБП', date: '2025-02-18' },
  { id: '2', amount: -1200, type: 'payment', description: 'Покупка: VIP статус Rust', date: '2025-02-17' },
  { id: '3', amount: 3500, type: 'refund', description: 'Возврат средств', date: '2025-02-15' },
  { id: '4', amount: -500, type: 'withdrawal', description: 'Вывод на карту', date: '2025-02-10' },
];

export function Finances() {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState('balance');

  if (!user) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><Wallet className="h-16 w-16 mx-auto mb-4 text-muted-foreground" /><h1 className="text-2xl font-bold mb-4">Вход required</h1><Button asChild><Link to="/auth">Войти</Link></Button></main></div>;

  const balance = profile?.balance || 0;

  const getTransactionIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'deposit': return <ArrowDownLeft className="h-5 w-5 text-green-600" />;
      case 'withdrawal': return <ArrowUpRight className="h-5 w-5 text-red-500" />;
      case 'payment': return <ArrowUpRight className="h-5 w-5 text-orange-500" />;
      case 'refund': return <ArrowDownLeft className="h-5 w-5 text-blue-500" />;
    }
  };

  const getTransactionBadge = (type: Transaction['type']) => {
    switch (type) {
      case 'deposit': return <Badge variant="default" className="bg-green-600">Пополнение</Badge>;
      case 'withdrawal': return <Badge variant="destructive">Вывод</Badge>;
      case 'payment': return <Badge variant="secondary">Оплата</Badge>;
      case 'refund': return <Badge variant="outline">Возврат</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/" className="flex items-center gap-1"><ChevronLeft className="h-4 w-4" />На главную</Link></Button>
        <h1 className="text-2xl font-bold mb-6">Финансы</h1>
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <p className="text-muted-foreground text-sm mb-1">Баланс</p>
                <div className="text-4xl font-bold">{balance.toLocaleString('ru-RU')} ₽</div>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <Button className="flex-1 sm:flex-none"><Plus className="h-4 w-4 mr-2" />Пополнить</Button>
                <Button variant="outline" className="flex-1 sm:flex-none"><ArrowUpRight className="h-4 w-4 mr-2" />Вывести</Button>
              </div>
            </div>
          </CardContent>
        </Card>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="balance"><History className="h-4 w-4 mr-2" />История</TabsTrigger>
            <TabsTrigger value="methods"><Wallet className="h-4 w-4 mr-2" />Способы оплаты</TabsTrigger>
          </TabsList>
          <TabsContent value="balance">
            <Card>
              <CardHeader className="pb-4"><CardTitle>История операций</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0">{getTransactionIcon(transaction.type)}</div>
                        <div>
                          <p className="font-medium">{transaction.description}</p>
                          <p className="text-sm text-muted-foreground">{new Date(transaction.date).toLocaleDateString('ru-RU')}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className={`font-semibold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-500'}`}>{transaction.amount > 0 ? '+' : ''}{transaction.amount.toLocaleString('ru-RU')} ₽</p>
                        <div className="mt-1">{getTransactionBadge(transaction.type)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="methods">
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <Wallet className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground mb-4">У вас пока нет сохраненных способов оплаты</p>
                  <Button>Добавить способ оплаты</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
