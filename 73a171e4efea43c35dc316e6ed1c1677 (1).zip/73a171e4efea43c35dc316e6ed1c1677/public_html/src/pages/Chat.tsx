import { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getChatById, getMessages, sendMessage, markMessagesAsRead, subscribeToMessages } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ChevronLeft, Send, ShoppingBag } from 'lucide-react';
// import { toast } from 'sonner';
import type { Message, Chat as ChatType } from '@/types';

export function Chat() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [chat, setChat] = useState<ChatType | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (!user) { navigate('/auth'); return; } loadChat(); }, [id, user]);

  useEffect(() => {
    if (chat?.id) {
      const subscription = subscribeToMessages(chat.id, (newMsg) => {
        setMessages(prev => [...prev, newMsg]);
        scrollToBottom();
        if (newMsg.sender_id !== user?.id) markMessagesAsRead(chat.id, user?.id || '');
      });
      return () => { subscription.unsubscribe(); };
    }
  }, [chat?.id]);

  useEffect(() => { scrollToBottom(); }, [messages]);

  const loadChat = async () => {
    if (!id) return;
    const { data: chatData } = await getChatById(id);
    if (chatData) {
      setChat(chatData as ChatType);
      if (chatData.buyer_id !== user?.id && chatData.seller_id !== user?.id) { navigate('/chats'); return; }
      const { data: messagesData } = await getMessages(id);
      if (messagesData) { setMessages(messagesData as Message[]); markMessagesAsRead(id, user?.id || ''); }
    }
    setLoading(false);
  };

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !chat || !user) return;
    setSending(true);
    const { error } = await sendMessage(chat.id, user.id, newMessage.trim());
    if (!error) setNewMessage('');
    setSending(false);
  };

  const otherUser = chat?.buyer_id === user?.id ? chat?.seller : chat?.buyer;
  // Реальная проверка онлайна - был ли пользователь активен в последние 5 минут
  const isOnline = otherUser?.last_online 
    ? (new Date().getTime() - new Date(otherUser.last_online).getTime()) < 5 * 60 * 1000 
    : false;

  if (loading) return <div className="min-h-screen bg-background flex flex-col"><Header /><div className="flex-1 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div></div>;
  if (!chat) return <div className="min-h-screen bg-background flex flex-col"><Header /><div className="flex-1 flex items-center justify-center text-center"><p className="text-muted-foreground">Чат не найден</p><Button asChild className="mt-4"><Link to="/chats">Назад к чатам</Link></Button></div></div>;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" asChild><Link to="/chats"><ChevronLeft className="h-5 w-5" /></Link></Button>
            <Avatar className="h-10 w-10"><AvatarImage src={otherUser?.avatar_url || ''} /><AvatarFallback>{otherUser?.username?.[0]}</AvatarFallback></Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{otherUser?.username}</p>
              <p className={`text-xs ${isOnline ? 'text-green-500' : 'text-muted-foreground'}`}>{isOnline ? 'онлайн' : 'офлайн'}</p>
            </div>
          </div>
        </div>
      </div>
      {chat.lot && (
        <div className="border-b bg-muted/50">
          <div className="container mx-auto px-4 py-2">
            <Link to={`/lot/${chat.lot.id}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors">
              <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                {chat.lot.images?.[0] ? <img src={chat.lot.images[0]} alt="" className="h-full w-full object-cover" /> : <ShoppingBag className="h-5 w-5 text-muted-foreground" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{chat.lot.title}</p>
                <p className="text-sm text-green-600 font-semibold">{chat.lot.price?.toLocaleString('ru-RU')} ₽</p>
              </div>
            </Link>
          </div>
        </div>
      )}
      <div className="flex-1 overflow-y-auto bg-muted/30">
        <div className="container mx-auto px-4 py-4 space-y-4">
          {messages.length === 0 ? <div className="text-center py-8"><p className="text-muted-foreground text-sm">Начните общение с {otherUser?.username}</p></div> : messages.map((message, index) => {
            const isMine = message.sender_id === user?.id;
            const showDate = index === 0 || new Date(messages[index - 1].created_at).toDateString() !== new Date(message.created_at).toDateString();
            return (
              <div key={message.id}>
                {showDate && <div className="flex justify-center my-4"><span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">{new Date(message.created_at).toLocaleDateString('ru-RU')}</span></div>}
                <div className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[70%] ${isMine ? 'bg-primary text-primary-foreground' : 'bg-card'} rounded-2xl px-4 py-2 shadow-sm`}>
                    <p className="text-sm">{message.content}</p>
                    <p className={`text-[10px] mt-1 ${isMine ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{new Date(message.created_at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="border-t bg-card p-4">
        <form onSubmit={handleSend} className="container mx-auto flex gap-2">
          <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Написать сообщение..." className="flex-1" />
          <Button type="submit" size="icon" disabled={sending || !newMessage.trim()}><Send className="h-4 w-4" /></Button>
        </form>
      </div>
    </div>
  );
}
