import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getCategories, getLots } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { CategoryCard } from '@/components/CategoryCard';
import { LotCard } from '@/components/LotCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Gamepad2, ChevronLeft } from 'lucide-react';
import type { Category, Lot } from '@/types';

export function Games() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [lots, setLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: cats } = await getCategories();
    if (cats) setCategories(cats as Category[]);
    const { data: lotsData } = await getLots({ status: 'active' });
    if (lotsData) setLots(lotsData as Lot[]);
    setLoading(false);
  };

  const games = categories.filter((c) => c.type === 'game');
  const apps = categories.filter((c) => c.type === 'app');
  const services = categories.filter((c) => c.type === 'service');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/" className="flex items-center gap-1"><ChevronLeft className="h-4 w-4" />На главную</Link></Button>
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-6"><Gamepad2 className="h-6 w-6 text-primary" /><h1 className="text-2xl font-bold">Все игры</h1></div>
          {loading ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4,5,6,7,8].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div> : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{games.map((game) => <CategoryCard key={game.id} category={game} />)}</div>}
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">Приложения</h2>
          {loading ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div> : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{apps.map((app) => <CategoryCard key={app.id} category={app} />)}</div>}
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">Услуги</h2>
          {loading ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div> : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{services.map((service) => <CategoryCard key={service.id} category={service} />)}</div>}
        </section>
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">Все лоты</h2>
          {loading ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{[1,2,3,4,5,6,7,8].map((i) => <Skeleton key={i} className="h-64 rounded-xl" />)}</div> : lots.length > 0 ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{lots.map((lot) => <LotCard key={lot.id} lot={lot} />)}</div> : <div className="text-center py-8"><p className="text-muted-foreground">Лоты не найдены</p></div>}
        </section>
      </main>
    </div>
  );
}
