import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getLotById, createChat, createOrder, getUserStats } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ChevronLeft, MessageSquare, Calendar, Package, Star, Shield, Clock, CheckCircle, ShoppingCart, Eye } from 'lucide-react';
import { toast } from 'sonner';
import type { Lot as LotType } from '@/types';

export function Lot() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [lot, setLot] = useState<LotType | null>(null);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [sellerStats, setSellerStats] = useState({ sales: 0, rating: 0, reviewsCount: 0 });

  useEffect(() => { if (id) loadLot(); }, [id]);

  const loadLot = async () => {
    setLoading(true);
    const { data } = await getLotById(id!);
    if (data) {
      setLot(data as LotType);
      // Загружаем статистику продавца
      if (data.seller_id) {
        const { data: stats } = await getUserStats(data.seller_id);
        if (stats) setSellerStats(stats);
      }
    }
    setLoading(false);
  };

  const handleChatClick = async () => {
    if (!user) { toast.error('Войдите в аккаунт'); navigate('/auth'); return; }
    if (lot?.seller_id === user.id) { toast.error('Вы не можете написать самому себе'); return; }
    setChatLoading(true);
    const { data: chat, error } = await createChat(lot!.id, user.id, lot!.seller_id);
    if (error) toast.error('Ошибка создания чата');
    else if (chat) navigate(`/chat/${chat.id}`);
    setChatLoading(false);
  };

  const handleBuy = async () => {
    if (!user) { toast.error('Войдите в аккаунт'); navigate('/auth'); return; }
    if (lot?.seller_id === user.id) { toast.error('Вы не можете купить свой лот'); return; }
    setBuying(true);
    const { error } = await createOrder({ lot_id: lot!.id, buyer_id: user.id, seller_id: lot!.seller_id, amount: lot!.price, status: 'pending' });
    if (error) toast.error('Ошибка создания заказа');
    else toast.success('Заказ создан! Перейдите в раздел "Мои покупки"');
    setBuying(false);
  };

  const discount = lot?.old_price ? Math.round(((lot.old_price - lot.price) / lot.old_price) * 100) : null;
  const isOwnLot = lot?.seller_id === user?.id;
  // Реальная проверка онлайна - был ли продавец активен в последние 5 минут
  const isOnline = lot?.seller?.last_online 
    ? (new Date().getTime() - new Date(lot.seller.last_online).getTime()) < 5 * 60 * 1000 
    : false;

  if (loading) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8"><Skeleton className="h-6 w-32 mb-6" /><div className="grid grid-cols-1 lg:grid-cols-2 gap-8"><Skeleton className="h-96 rounded-xl" /><div className="space-y-4"><Skeleton className="h-8 w-3/4" /><Skeleton className="h-6 w-1/2" /><Skeleton className="h-24 w-full" /><Skeleton className="h-12 w-full" /></div></div></main></div>;
  if (!lot) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><h1 className="text-2xl font-bold mb-4">Лот не найден</h1><Button asChild><Link to="/">На главную</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <Link to="/" className="hover:text-primary">Главная</Link>
          <ChevronLeft className="h-4 w-4 rotate-180" />
          <Link to={`/category/${lot.category?.slug}`} className="hover:text-primary">{lot.category?.name}</Link>
          <ChevronLeft className="h-4 w-4 rotate-180" />
          <span className="text-foreground truncate">{lot.title}</span>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <div className="relative aspect-square rounded-xl overflow-hidden border bg-card">
              {lot.images && lot.images.length > 0 ? <img src={lot.images[0]} alt={lot.title} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5"><span className="text-7xl font-bold text-primary/30">{lot.title.charAt(0)}</span></div>}
              {discount && discount > 0 && <Badge className="absolute top-4 right-4 bg-red-500 text-white text-lg px-3 py-1">-{discount}%</Badge>}
            </div>
          </div>
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary">{lot.category?.name}</Badge>
                {lot.subcategory && <Badge variant="outline">{lot.subcategory.name}</Badge>}
                {lot.status === 'active' && <Badge className="bg-green-600">Активен</Badge>}
              </div>
              <h1 className="text-2xl font-bold">{lot.title}</h1>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Eye className="h-4 w-4" />{lot.views || 0} просмотров</span>
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(lot.created_at).toLocaleDateString('ru-RU')}</span>
              </div>
            </div>
            <div className="flex items-end gap-4">
              <div className="text-4xl font-bold text-green-600 dark:text-green-400">{lot.price.toLocaleString('ru-RU')} ₽</div>
              {lot.old_price && <div className="text-xl text-muted-foreground line-through pb-1">{lot.old_price.toLocaleString('ru-RU')} ₽</div>}
            </div>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Link to={`/profile/${lot.seller_id}`}><Avatar className="h-14 w-14 cursor-pointer"><AvatarImage src={lot.seller?.avatar_url || ''} /><AvatarFallback>{lot.seller?.username?.[0]}</AvatarFallback></Avatar></Link>
                  <div className="flex-1">
                    <Link to={`/profile/${lot.seller_id}`} className="font-medium hover:text-primary text-lg">{lot.seller?.username}</Link>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                      <span className={`flex items-center gap-1 ${isOnline ? 'text-green-500' : ''}`}><span className={`h-2 w-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />{isOnline ? 'онлайн' : 'офлайн'}</span>
                      <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />{sellerStats.rating.toFixed(1)}</span>
                      <span>{sellerStats.sales} продаж</span>
                      <span>{sellerStats.reviewsCount} отзывов</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <div>
              <h3 className="font-semibold mb-2">Описание</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{lot.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground"><Package className="h-4 w-4" /><span>В наличии: {lot.quantity} шт.</span></div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground"><Shield className="h-4 w-4" /><span>Безопасная сделка</span></div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground"><Clock className="h-4 w-4" /><span>Быстрая доставка</span></div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground"><CheckCircle className="h-4 w-4" /><span>Гарантия качества</span></div>
            </div>
            {!isOwnLot ? (
              <div className="flex gap-3 pt-4">
                <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white h-12 text-lg" onClick={handleBuy} disabled={buying || lot.status !== 'active'}><ShoppingCart className="h-5 w-5 mr-2" />{buying ? 'Обработка...' : 'Купить'}</Button>
                <Button variant="outline" className="h-12 px-6" onClick={handleChatClick} disabled={chatLoading}><MessageSquare className="h-5 w-5 mr-2" />Написать</Button>
              </div>
            ) : (
              <div className="flex gap-3 pt-4"><Button variant="outline" className="flex-1 h-12" asChild><Link to="/my-lots">Управление лотом</Link></Button></div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
