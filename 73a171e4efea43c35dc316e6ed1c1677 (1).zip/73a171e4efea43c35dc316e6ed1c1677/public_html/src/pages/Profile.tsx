import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getProfile, getLots, getUserReviews, getUserStats, createChat } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { LotCard } from '@/components/LotCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ChevronLeft, Calendar, Package, Star, MessageSquare, TrendingUp, Shield, Clock, Settings, User } from 'lucide-react';
import { toast } from 'sonner';
import type { Profile as ProfileType, Lot, Review } from '@/types';

export function Profile() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile: currentUserProfile } = useAuth();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [lots, setLots] = useState<Lot[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState({ sales: 0, rating: 0, reviewsCount: 0 });
  const [loading, setLoading] = useState(true);
  const [chatLoading, setChatLoading] = useState(false);

  useEffect(() => { if (id) loadProfileData(); }, [id]);

  const loadProfileData = async () => {
    setLoading(true);
    const { data: p } = await getProfile(id!);
    if (p) {
      setProfile(p as ProfileType);
      const { data: lotsData } = await getLots({ seller_id: id! });
      if (lotsData) setLots(lotsData as Lot[]);
      
      // Загружаем отзывы
      const { data: reviewsData } = await getUserReviews(id!);
      if (reviewsData) setReviews(reviewsData as Review[]);
      
      // Загружаем статистику
      const { data: statsData } = await getUserStats(id!);
      if (statsData) setStats(statsData);
    }
    setLoading(false);
  };

  // Реальная проверка онлайна - считаем онлайн если last_online был в последние 5 минут
  const isOnline = profile?.last_online 
    ? (new Date().getTime() - new Date(profile.last_online).getTime()) < 5 * 60 * 1000 
    : false;
  
  // Формат даты: ДД.ММ.ГГ ЧЧ:ММ
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().slice(-2);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}.${month}.${year} ${hours}:${minutes}`;
  };
  
  const lastOnlineText = profile?.last_online ? formatDateTime(profile.last_online) : '';

  const handleChatClick = async () => {
    if (!user) { toast.error('Войдите в аккаунт'); navigate('/auth'); return; }
    if (profile?.id === user.id) { toast.error('Вы не можете написать самому себе'); return; }
    
    setChatLoading(true);
    // Создаем чат без лота (просто чат с пользователем)
    const { data: chat, error } = await createChat('direct', user.id, profile!.id);
    if (error) {
      // Если чат уже существует, перенаправляем на него
      if (error.message?.includes('unique')) {
        navigate(`/chats`);
      } else {
        toast.error('Ошибка создания чата');
      }
    } else if (chat) {
      navigate(`/chat/${chat.id}`);
    }
    setChatLoading(false);
  };

  if (loading) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8"><Skeleton className="h-8 w-32 mb-6" /><div className="flex items-center gap-4 mb-8"><Skeleton className="h-24 w-24 rounded-full" /><div className="space-y-2"><Skeleton className="h-6 w-32" /><Skeleton className="h-4 w-24" /></div></div></main></div>;
  if (!profile) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><h1 className="text-2xl font-bold mb-4">Профиль не найден</h1><Button asChild><Link to="/">На главную</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/" className="flex items-center gap-1"><ChevronLeft className="h-4 w-4" />Назад</Link></Button>
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="relative">
              <Avatar className="h-24 w-24 sm:h-32 sm:w-32 border-4 border-background shadow-lg"><AvatarImage src={profile.avatar_url || ''} /><AvatarFallback className="text-3xl">{profile.username?.[0]}</AvatarFallback></Avatar>
              <span className={`absolute bottom-2 right-2 h-5 w-5 rounded-full border-4 border-background ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-bold">{profile.username}</h1>
                <Badge variant="secondary" className="flex items-center gap-1"><Shield className="h-3 w-3" />Проверен</Badge>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-2 text-sm text-muted-foreground">
                <span className={`flex items-center gap-1 ${isOnline ? 'text-green-500' : ''}`}><span className={`h-2 w-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />{isOnline ? 'онлайн' : `был ${lastOnlineText}`}</span>
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />На сайте с {new Date(profile.created_at).toLocaleDateString('ru-RU')}</span>
              </div>
              <div className="flex gap-2 mt-4">
                {profile.id !== user?.id && (
                  <Button variant="outline" size="sm" onClick={handleChatClick} disabled={chatLoading}>
                    <MessageSquare className="h-4 w-4 mr-2" />Написать
                  </Button>
                )}
                {profile.id === user?.id && (
                  <Button variant="outline" size="sm" asChild><Link to="/settings"><Settings className="h-4 w-4 mr-2" />Настройки</Link></Button>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-2"><Package className="h-4 w-4 text-primary" /><span className="text-sm text-muted-foreground">Лотов</span></div><div className="text-2xl font-bold">{lots.length}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-2"><TrendingUp className="h-4 w-4 text-green-600" /><span className="text-sm text-muted-foreground">Продаж</span></div><div className="text-2xl font-bold">{stats.sales}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-2"><Star className="h-4 w-4 text-yellow-400" /><span className="text-sm text-muted-foreground">Рейтинг</span></div><div className="text-2xl font-bold">{stats.rating.toFixed(1)}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-2"><Clock className="h-4 w-4 text-blue-500" /><span className="text-sm text-muted-foreground">Отзывов</span></div><div className="text-2xl font-bold">{stats.reviewsCount}</div></CardContent></Card>
        </div>
        
        {/* Секция отзывов */}
        {reviews.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-bold mb-4">Отзывы ({reviews.length})</h2>
            <div className="space-y-4">
              {reviews.map((review) => {
                // Показываем никнейм только админу или продавцу
                const showUsername = currentUserProfile?.is_admin || profile?.id === user?.id;
                return (
                  <Card key={review.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={review.reviewer?.avatar_url || ''} />
                          <AvatarFallback><User className="h-5 w-5" /></AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium">
                              {showUsername ? review.reviewer?.username : 'Пользователь'}
                            </span>
                            <div className="flex items-center gap-1">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-4 w-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {formatDateTime(review.created_at)}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">{review.comment}</p>
                          {review.lot && (
                            <p className="text-xs text-muted-foreground mt-2">
                              Лот: {review.lot.title}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        )}
        <section>
          <h2 className="text-xl font-bold mb-4">Активные лоты</h2>
          {lots.length > 0 ? <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{lots.map((lot) => <LotCard key={lot.id} lot={lot} />)}</div> : <div className="text-center py-12 border rounded-xl"><p className="text-muted-foreground">У пользователя пока нет активных лотов</p></div>}
        </section>
      </main>
    </div>
  );
}
