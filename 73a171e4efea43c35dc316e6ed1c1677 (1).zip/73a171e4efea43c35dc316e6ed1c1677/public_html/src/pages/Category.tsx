import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getCategoryBySlug, getSubcategories, getLots } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { LotCard } from '@/components/LotCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ChevronLeft, Filter } from 'lucide-react';
import type { Category as CategoryType, Subcategory, Lot } from '@/types';

export function Category() {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<CategoryType | null>(null);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [lots, setLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);

  useEffect(() => { if (slug) loadData(); }, [slug]);

  const loadData = async () => {
    setLoading(true);
    const { data: cat } = await getCategoryBySlug(slug!);
    if (cat) {
      setCategory(cat as CategoryType);
      const { data: subs } = await getSubcategories(cat.id);
      if (subs) setSubcategories(subs as Subcategory[]);
      const { data: lotsData } = await getLots({ category_id: cat.id });
      if (lotsData) setLots(lotsData as Lot[]);
    }
    setLoading(false);
  };

  const filteredLots = selectedSubcategory ? lots.filter((l) => l.subcategory_id === selectedSubcategory) : lots;

  if (loading) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8"><Skeleton className="h-8 w-48 mb-6" /><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4].map(i => <Skeleton key={i} className="h-64 rounded-xl" />)}</div></main></div>;
  if (!category) return <div className="min-h-screen bg-background"><Header /><main className="container mx-auto px-4 py-8 text-center"><h1 className="text-2xl font-bold mb-4">Категория не найдена</h1><Button asChild><Link to="/">На главную</Link></Button></main></div>;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <Link to="/" className="hover:text-primary">Главная</Link>
          <ChevronLeft className="h-4 w-4 rotate-180" />
          <span className="text-foreground">{category.name}</span>
        </div>
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <span className="text-3xl font-bold text-primary">{category.name.charAt(0)}</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold">{category.name}</h1>
              <p className="text-muted-foreground">{lots.length} {lots.length === 1 ? 'лот' : lots.length < 5 ? 'лота' : 'лотов'}</p>
            </div>
          </div>
        </div>
        {subcategories.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3"><Filter className="h-4 w-4" /><span className="font-medium">Подкатегории</span></div>
            <div className="flex flex-wrap gap-2">
              <Button variant={selectedSubcategory === null ? 'default' : 'outline'} size="sm" onClick={() => setSelectedSubcategory(null)}>Все</Button>
              {subcategories.map((sub) => <Button key={sub.id} variant={selectedSubcategory === sub.id ? 'default' : 'outline'} size="sm" onClick={() => setSelectedSubcategory(sub.id)}>{sub.name}</Button>)}
            </div>
          </div>
        )}
        <section>
          <h2 className="text-lg font-semibold mb-4">Лоты</h2>
          {filteredLots.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredLots.map((lot) => <LotCard key={lot.id} lot={lot} />)}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-xl">
              <p className="text-muted-foreground mb-4">В этой категории пока нет лотов</p>
              <Button asChild><Link to="/sell">Создать лот</Link></Button>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
