import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Auth
export const signInWithGoogle = () => supabase.auth.signInWithOAuth({
  provider: 'google',
  options: { redirectTo: `${window.location.origin}/#/auth/callback` }
});

export const signInWithEmail = (email: string, password: string) =>
  supabase.auth.signInWithPassword({ email, password });

export const signUpWithEmail = (email: string, password: string, username: string) =>
  supabase.auth.signUp({
    email,
    password,
    options: { data: { username }, emailRedirectTo: `${window.location.origin}/#/auth/callback` }
  });

export const signOut = () => supabase.auth.signOut();

// Profiles
export const getProfile = (userId: string) =>
  supabase.from('profiles').select('*').eq('id', userId).single();

export const updateProfile = (userId: string, updates: any) =>
  supabase.from('profiles').update(updates).eq('id', userId);

export const updateUserStatus = (status: 'online' | 'offline') =>
  supabase.auth.getUser().then(({ data: { user } }) => {
    if (user) {
      return supabase.from('profiles').update({ status, last_online: new Date().toISOString() }).eq('id', user.id);
    }
  });

// Categories
export const getCategories = () =>
  supabase.from('categories').select('*').eq('is_active', true).order('order_num');

export const getCategoryBySlug = (slug: string) =>
  supabase.from('categories').select('*').eq('slug', slug).eq('is_active', true).single();

export const getSubcategories = (categoryId: string) =>
  supabase.from('subcategories').select('*').eq('category_id', categoryId).eq('is_active', true).order('order_num');

export const createCategory = (category: any) =>
  supabase.from('categories').insert(category).select().single();

export const updateCategory = (id: string, updates: any) =>
  supabase.from('categories').update(updates).eq('id', id).select().single();

export const deleteCategory = (id: string) =>
  supabase.from('categories').delete().eq('id', id);

export const createSubcategory = (subcategory: any) =>
  supabase.from('subcategories').insert(subcategory).select().single();

export const deleteSubcategory = (id: string) =>
  supabase.from('subcategories').delete().eq('id', id);

// Lots
export const getLots = (filters?: { category_id?: string; subcategory_id?: string; seller_id?: string; status?: string }) => {
  let query = supabase.from('lots').select('*, seller:profiles(id, username, avatar_url, status), category:categories(id, name, slug), subcategory:subcategories(id, name, slug)').eq('status', filters?.status || 'active');
  if (filters?.category_id) query = query.eq('category_id', filters.category_id);
  if (filters?.subcategory_id) query = query.eq('subcategory_id', filters.subcategory_id);
  if (filters?.seller_id) query = query.eq('seller_id', filters.seller_id);
  return query.order('created_at', { ascending: false });
};

export const getLotById = (id: string) =>
  supabase.from('lots').select('*, seller:profiles(id, username, avatar_url, status, created_at), category:categories(id, name, slug), subcategory:subcategories(id, name, slug)').eq('id', id).single();

export const createLot = (lot: any) =>
  supabase.from('lots').insert(lot).select().single();

export const updateLot = (id: string, updates: any) =>
  supabase.from('lots').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();

export const deleteLot = (id: string) =>
  supabase.from('lots').delete().eq('id', id);

// Chats
export const getChats = (userId: string) =>
  supabase.from('chats').select('*, lot:lots(id, title, price, images), buyer:profiles!chats_buyer_id_fkey(id, username, avatar_url, status), seller:profiles!chats_seller_id_fkey(id, username, avatar_url, status)').or(`buyer_id.eq.${userId},seller_id.eq.${userId}`).order('updated_at', { ascending: false });

export const getChatById = (chatId: string) =>
  supabase.from('chats').select('*, lot:lots(id, title, price, images), buyer:profiles!chats_buyer_id_fkey(id, username, avatar_url, status), seller:profiles!chats_seller_id_fkey(id, username, avatar_url, status)').eq('id', chatId).single();

export const createChat = async (lotId: string, buyerId: string, sellerId: string) => {
  // Для прямых чатов (без лота) используем специальный lot_id = 'direct'
  if (lotId === 'direct') {
    const { data: existing } = await supabase
      .from('chats')
      .select('*')
      .eq('lot_id', 'direct')
      .or(`and(buyer_id.eq.${buyerId},seller_id.eq.${sellerId}),and(buyer_id.eq.${sellerId},seller_id.eq.${buyerId})`)
      .maybeSingle();
    if (existing) return { data: existing, error: null };
    return supabase.from('chats').insert({ lot_id: 'direct', buyer_id: buyerId, seller_id: sellerId }).select().single();
  }
  
  const { data: existing } = await supabase.from('chats').select('*').eq('lot_id', lotId).eq('buyer_id', buyerId).eq('seller_id', sellerId).maybeSingle();
  if (existing) return { data: existing, error: null };
  return supabase.from('chats').insert({ lot_id: lotId, buyer_id: buyerId, seller_id: sellerId }).select().single();
};

// Messages
export const getMessages = (chatId: string) =>
  supabase.from('messages').select('*, sender:profiles(id, username, avatar_url)').eq('chat_id', chatId).order('created_at', { ascending: true });

export const sendMessage = async (chatId: string, senderId: string, content: string) => {
  const result = await supabase.from('messages').insert({ chat_id: chatId, sender_id: senderId, content }).select().single();
  if (!result.error) {
    await supabase.from('chats').update({ updated_at: new Date().toISOString() }).eq('id', chatId);
  }
  return result;
};

export const markMessagesAsRead = (chatId: string, userId: string) =>
  supabase.from('messages').update({ is_read: true }).eq('chat_id', chatId).neq('sender_id', userId).eq('is_read', false);

export const subscribeToMessages = (chatId: string, callback: (message: any) => void) =>
  supabase.channel(`chat:${chatId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` }, (payload: any) => callback(payload.new)).subscribe();

export const subscribeToChats = (userId: string, callback: (chat: any) => void) =>
  supabase.channel(`user_chats:${userId}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'chats', filter: `buyer_id=eq.${userId}` }, (payload: any) => callback(payload.new))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'chats', filter: `seller_id=eq.${userId}` }, (payload: any) => callback(payload.new))
    .subscribe();

// Orders
export const createOrder = (order: any) =>
  supabase.from('orders').insert(order).select().single();

// Reviews
export const getUserReviews = (sellerId: string) =>
  supabase.from('reviews').select('*, reviewer:profiles!reviewer_id(id, username, avatar_url), lot:lots(id, title)').eq('seller_id', sellerId).order('created_at', { ascending: false });

export const createReview = (review: any) =>
  supabase.from('reviews').insert(review).select().single();

// User Stats
export const getUserStats = async (userId: string) => {
  // Получаем количество продаж (завершенных заказов)
  const { data: salesData } = await supabase
    .from('orders')
    .select('id')
    .eq('seller_id', userId)
    .eq('status', 'completed');
  
  // Получаем отзывы для расчета рейтинга
  const { data: reviewsData } = await supabase
    .from('reviews')
    .select('rating')
    .eq('seller_id', userId);
  
  const sales = salesData?.length || 0;
  const reviewsCount = reviewsData?.length || 0;
  
  // Считаем средний рейтинг
  let rating = 0;
  if (reviewsData && reviewsData.length > 0) {
    const sum = reviewsData.reduce((acc, r) => acc + r.rating, 0);
    rating = sum / reviewsData.length;
  }
  
  return { 
    data: { sales, rating, reviewsCount }, 
    error: null 
  };
};

// Admin
export const isAdmin = async (userId: string) => {
  const { data } = await supabase.from('profiles').select('is_admin').eq('id', userId).single();
  return data?.is_admin || false;
};

// Site Settings
export const getSiteSettings = () =>
  supabase.from('site_settings').select('*').single();

export const updateSiteSettings = (settings: any) =>
  supabase.from('site_settings').update(settings).eq('id', '1').select().single();

// Upload
export const uploadAvatar = async (userId: string, file: File) => {
  try {
    const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const fileName = `${userId}-${Date.now()}.${fileExt}`;
    
    // Пробуем загрузить в bucket 'avatars'
    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(fileName, file, { 
        cacheControl: '3600', 
        upsert: true,
        contentType: file.type
      });
    
    if (uploadError) {
      console.error('Upload error:', uploadError);
      return { error: uploadError, data: null };
    }
    
    const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(fileName);
    
    // Обновляем профиль с новой аватаркой
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ avatar_url: publicUrl })
      .eq('id', userId);
    
    if (updateError) {
      console.error('Profile update error:', updateError);
      return { error: updateError, data: null };
    }
    
    return { data: publicUrl, error: null };
  } catch (err: any) {
    console.error('Avatar upload error:', err);
    return { error: err, data: null };
  }
};
