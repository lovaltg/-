-- ============================================
-- СХЕМА БАЗЫ ДАННЫХ ДЛЯ MARKETPLACE
-- ============================================

-- Таблица профилей пользователей
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  avatar_url TEXT,
  balance DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_online TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  nickname_changed_at TIMESTAMP WITH TIME ZONE,
  is_admin BOOLEAN DEFAULT FALSE,
  status TEXT DEFAULT 'offline'
);

-- Таблица категорий
CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('game', 'app', 'service')),
  icon TEXT,
  image_url TEXT,
  order_num INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Таблица подкатегорий
CREATE TABLE IF NOT EXISTS subcategories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  order_num INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(category_id, slug)
);

-- Таблица лотов
CREATE TABLE IF NOT EXISTS lots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES categories(id),
  subcategory_id UUID REFERENCES subcategories(id),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  old_price DECIMAL(10,2),
  quantity INTEGER DEFAULT 1,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'sold', 'inactive', 'pending')),
  images TEXT[] DEFAULT '{}',
  views INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Таблица чатов
CREATE TABLE IF NOT EXISTS chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id TEXT NOT NULL,
  buyer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  seller_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(lot_id, buyer_id, seller_id)
);

-- Таблица сообщений
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Таблица заказов
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id UUID NOT NULL REFERENCES lots(id),
  buyer_id UUID NOT NULL REFERENCES profiles(id),
  seller_id UUID NOT NULL REFERENCES profiles(id),
  amount DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'completed', 'cancelled', 'disputed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Таблица отзывов
CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  lot_id UUID REFERENCES lots(id) ON DELETE SET NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(seller_id, reviewer_id, lot_id)
);

-- Таблица настроек сайта
CREATE TABLE IF NOT EXISTS site_settings (
  id TEXT PRIMARY KEY DEFAULT '1',
  site_name TEXT DEFAULT 'GameMarket',
  site_logo TEXT,
  support_telegram TEXT DEFAULT '@LovelyConfig',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- SEED ДАННЫЕ
-- ============================================

-- Популярные игры
INSERT INTO categories (name, slug, type, order_num) VALUES
('Rust', 'rust', 'game', 1),
('CS2', 'cs2', 'game', 2),
('Dota 2', 'dota-2', 'game', 3),
('PUBG', 'pubg', 'game', 4),
('Fortnite', 'fortnite', 'game', 5),
('Valorant', 'valorant', 'game', 6),
('GTA V', 'gta-5', 'game', 7),
('Minecraft', 'minecraft', 'game', 8),
('World of Tanks', 'world-of-tanks', 'game', 9),
('War Thunder', 'war-thunder', 'game', 10),
('Escape from Tarkov', 'escape-from-tarkov', 'game', 11),
('Apex Legends', 'apex-legends', 'game', 12),
('League of Legends', 'league-of-legends', 'game', 13),
('Roblox', 'roblox', 'game', 14),
('Genshin Impact', 'genshin-impact', 'game', 15)
ON CONFLICT (slug) DO NOTHING;

-- Приложения
INSERT INTO categories (name, slug, type, order_num) VALUES
('Steam', 'steam', 'app', 16),
('Epic Games', 'epic-games', 'app', 17),
('Discord', 'discord', 'app', 18),
('Spotify', 'spotify', 'app', 19),
('Netflix', 'netflix', 'app', 20),
('YouTube Premium', 'youtube-premium', 'app', 21)
ON CONFLICT (slug) DO NOTHING;

-- Услуги
INSERT INTO categories (name, slug, type, order_num) VALUES
('Telegram', 'telegram', 'service', 22),
('Instagram', 'instagram', 'service', 23),
('TikTok', 'tiktok', 'service', 24),
('VK', 'vk', 'service', 25),
('Прокси', 'proxy', 'service', 26),
('VPN', 'vpn', 'service', 27)
ON CONFLICT (slug) DO NOTHING;

-- Подкатегории для игр
INSERT INTO subcategories (category_id, name, slug, order_num)
SELECT id, 'Аккаунты', 'accounts', 1 FROM categories WHERE slug = 'rust'
UNION ALL
SELECT id, 'Скины', 'skins', 2 FROM categories WHERE slug = 'rust'
UNION ALL
SELECT id, 'Предметы', 'items', 3 FROM categories WHERE slug = 'rust'
UNION ALL
SELECT id, 'Аккаунты', 'accounts', 1 FROM categories WHERE slug = 'cs2'
UNION ALL
SELECT id, 'Скины', 'skins', 2 FROM categories WHERE slug = 'cs2'
UNION ALL
SELECT id, 'Ключи', 'keys', 3 FROM categories WHERE slug = 'cs2'
UNION ALL
SELECT id, 'Аккаунты', 'accounts', 1 FROM categories WHERE slug = 'dota-2'
UNION ALL
SELECT id, 'Предметы', 'items', 2 FROM categories WHERE slug = 'dota-2'
UNION ALL
SELECT id, 'Аккаунты', 'accounts', 1 FROM categories WHERE slug = 'pubg'
UNION ALL
SELECT id, 'UC', 'uc', 2 FROM categories WHERE slug = 'pubg'
ON CONFLICT DO NOTHING;

-- Настройки сайта
INSERT INTO site_settings (id, site_name, support_telegram) VALUES ('1', 'GameMarket', '@LovelyConfig')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- RLS ПОЛИТИКИ (Row Level Security)
-- ============================================

-- Включаем RLS для всех таблиц
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE subcategories ENABLE ROW LEVEL SECURITY;
ALTER TABLE lots ENABLE ROW LEVEL SECURITY;
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Профили: чтение для всех, изменение только для владельца
CREATE POLICY "Profiles are viewable by everyone" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Категории: чтение для всех, изменение только для админов
CREATE POLICY "Categories are viewable by everyone" ON categories FOR SELECT USING (true);
CREATE POLICY "Only admins can modify categories" ON categories FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Подкатегории: чтение для всех, изменение только для админов
CREATE POLICY "Subcategories are viewable by everyone" ON subcategories FOR SELECT USING (true);
CREATE POLICY "Only admins can modify subcategories" ON subcategories FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Лоты: чтение для всех, изменение только для владельца
CREATE POLICY "Lots are viewable by everyone" ON lots FOR SELECT USING (true);
CREATE POLICY "Users can create lots" ON lots FOR INSERT WITH CHECK (auth.uid() = seller_id);
CREATE POLICY "Users can update own lots" ON lots FOR UPDATE USING (auth.uid() = seller_id);
CREATE POLICY "Users can delete own lots" ON lots FOR DELETE USING (auth.uid() = seller_id);

-- Чаты: доступ только для участников
CREATE POLICY "Users can view their chats" ON chats FOR SELECT USING (
  auth.uid() = buyer_id OR auth.uid() = seller_id
);
CREATE POLICY "Users can create chats" ON chats FOR INSERT WITH CHECK (
  auth.uid() = buyer_id OR auth.uid() = seller_id
);

-- Сообщения: доступ только для участников чата
CREATE POLICY "Users can view messages in their chats" ON messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM chats WHERE id = messages.chat_id AND (buyer_id = auth.uid() OR seller_id = auth.uid()))
);
CREATE POLICY "Users can send messages" ON messages FOR INSERT WITH CHECK (
  sender_id = auth.uid() AND
  EXISTS (SELECT 1 FROM chats WHERE id = messages.chat_id AND (buyer_id = auth.uid() OR seller_id = auth.uid()))
);

-- Заказы: доступ для покупателя и продавца
CREATE POLICY "Users can view their orders" ON orders FOR SELECT USING (
  auth.uid() = buyer_id OR auth.uid() = seller_id
);

-- Отзывы: чтение для всех, создание только для авторизованных
CREATE POLICY "Reviews are viewable by everyone" ON reviews FOR SELECT USING (true);
CREATE POLICY "Authenticated users can create reviews" ON reviews FOR INSERT WITH CHECK (auth.uid() = reviewer_id);
CREATE POLICY "Users can delete own reviews" ON reviews FOR DELETE USING (auth.uid() = reviewer_id);

-- Настройки сайта: чтение для всех, изменение только для админов
CREATE POLICY "Site settings are viewable by everyone" ON site_settings FOR SELECT USING (true);
CREATE POLICY "Only admins can modify site settings" ON site_settings FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);

-- ============================================
-- ФУНКЦИИ И ТРИГГЕРЫ
-- ============================================

-- Функция для обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Триггеры для updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_lots_updated_at BEFORE UPDATE ON lots
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chats_updated_at BEFORE UPDATE ON chats
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON site_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Функция для создания профиля при регистрации
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, email, is_admin)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.email,
    false
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Триггер для создания профиля
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- STORAGE BUCKETS
-- ============================================

-- Создаем bucket для аватарок
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Создаем bucket для изображений лотов
INSERT INTO storage.buckets (id, name, public) VALUES ('lot-images', 'lot-images', true)
ON CONFLICT (id) DO NOTHING;

-- Политики для storage
CREATE POLICY "Avatar images are publicly accessible" ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');
CREATE POLICY "Authenticated users can upload avatars" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');
CREATE POLICY "Users can update own avatars" ON storage.objects FOR UPDATE
  USING (bucket_id = 'avatars' AND owner = auth.uid());

CREATE POLICY "Lot images are publicly accessible" ON storage.objects FOR SELECT
  USING (bucket_id = 'lot-images');
CREATE POLICY "Authenticated users can upload lot images" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'lot-images' AND auth.role() = 'authenticated');
